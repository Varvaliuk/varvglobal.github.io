VARV GLOBAL — bilingual business landing page
============================================

HOW TO OPEN
1. Open index.html in a modern browser (Chrome, Safari, Edge, Firefox).
2. Language switch: EN / RU. No server or frameworks are needed.
3. Responsive design for desktop and mobile.

CONTACTS ON THE SITE
Primary WhatsApp Business: +86 156 0671 5790 (https://wa.me/8615606715790)
Primary email: motyafun007@gmail.com
Additional email: financenevelskoy@gmail.com
Additional email: mvarvalyuk@mail.ru
Personal WhatsApp: +7 914 412 8394 (https://wa.me/79144128394)
The contact cards open the corresponding email app or WhatsApp chat.

INQUIRY FORM
After a visitor completes the form, the site composes a request and opens
WhatsApp Business with a prefilled message. The visitor MUST manually tap
Send in WhatsApp. No server-side mail delivery or database storage is set up.
A copyable version of the inquiry also remains on the webpage.

HOW TO PUBLISH
Option A: Netlify -> Add new project -> Deploy manually -> drag and drop this folder.
Option B: GitHub Pages -> upload files to a repository -> Settings -> Pages.
Option C: Any static host -> upload index.html and assets/ to the site's public folder.

BEFORE PUBLISHING
- Review personal contact visibility: all five channels will be publicly visible.
- Confirm services, target markets, legal registration details, privacy policy,
  brand and domain availability.
- Add backend/form processing only if automatic inquiry delivery is required.

FILES
index.html: bilingual website with inline CSS and JavaScript
assets/varv-logo.webp: company logo
assets/favicon.svg: V favicon
